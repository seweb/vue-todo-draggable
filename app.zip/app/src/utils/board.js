import { uuid } from 'vue-uuid'
export default {
  data: [
    {
      id: uuid.v1(),
      name: "name1",
      description: "description1 description1 description1 description1 description1 description1 "
    },
    {
      id: uuid.v1(),
      name: "name2",
      description: "description2"
    },
    {
      id: uuid.v1(),
      name: "name3",
      description: "description3"
    },
    {
      id: uuid.v1(),
      name: "name4",
      description: "description4"
    },
    {
      id: uuid.v1(),
      name: "name5",
      description: "description5"
    },
    {
      id: uuid.v1(),
      name: "name6",
      description: "description6"
    },
  ]  
}
